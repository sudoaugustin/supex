"use strict";(()=>{var t={matches:["https://*.ng.co/*"],matchFallback:!0};document.body.style.background="blue";})();
