"use strict";(()=>{chrome.devtools.panels.create("My Panel","/assets/icon@1.png","/devtools/panels/profiler.html");})();
