"use strict";(()=>{var t=!1;function e(){t=!t,console.log(`State: ${t}`)}e();e();})();
